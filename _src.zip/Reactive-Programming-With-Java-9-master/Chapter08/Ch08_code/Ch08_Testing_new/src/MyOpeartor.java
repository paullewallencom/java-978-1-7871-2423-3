import io.reactivex.Observable;
import io.reactivex.Single;

public class MyOpeartor {
	
	public Observable<int[]> createObservable() {
		return null;
	}
	
	public Single<String> getSingleValue()
	{
		return null;
	}
	

}
