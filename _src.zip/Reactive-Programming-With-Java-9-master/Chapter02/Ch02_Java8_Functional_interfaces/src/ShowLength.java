
public class ShowLength {

	public void show(int length){
		System.out.println("length is:-"+length +" cm");
	}
	public static void main(String[] args) {
		ShowLength showLength=new ShowLength();
		showLength.show(100);
	}
	
}
